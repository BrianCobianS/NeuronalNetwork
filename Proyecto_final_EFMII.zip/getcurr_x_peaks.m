function corrientesal =getcurr_x_peaks(imp_max,pks)
corrientesal=length(pks)/imp_max;
end
