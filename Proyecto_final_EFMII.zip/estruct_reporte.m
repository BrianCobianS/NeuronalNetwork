caracter_programa.tiempototal=0;
caracter_programa.barridos=0;
caracter_programa.batchestime=0;
caracter_programa.impinicialcant=0;
caracter_programa.vectcorrIn=NaN;
caracter_programa.aleator_selec=NaN;
caracter_programa.estructura=NaN;